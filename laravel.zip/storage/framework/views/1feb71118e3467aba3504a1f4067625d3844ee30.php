<!doctype html>



<?php $__env->startSection('content'); ?>

<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Admin - IT TODAY 2018</title>
        <link rel="shortcut icon" href="img/logoittodayhitam.png" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="<?php echo e(asset('css/themify-icons.css')); ?>" rel="stylesheet" type="text/css" media="all" />
        <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" media="all" />
        <link href="<?php echo e(asset('css/theme.css')); ?>" rel="stylesheet" type="text/css" media="all" />
        <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" type="text/css" media="all" />
        <link href='http://fonts.googleapis.com/css?family=Lato:300,400%7CRaleway:100,400,300,500,600,700%7COpen+Sans:400,500,600' rel='stylesheet' type='text/css'>
    </head>
    <body style="background:url(<?php echo e(url('img/footer.png')); ?>) no-repeat center center fixed; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover;  background-size: cover;">
		
		<div class="main-container">

            <section  style="padding: 20px 0;">
		        <div class="container">
		            <div class="row">
					<h1 align="center"> ADMIN PANEL </h1>
                    <div class="feature bordered text-center bg-secondary" style="background-color: white; box-shadow: 0 9px 30px 10px rgba(0, 0, 0, 0.2);" align="center">
						<h4 class="uppercase mb40 mb-xs-24"><?php echo e($user->type); ?></h4>
						<div class="mb40">
							<h6 class="mb8 uppercase">Members</h6>
							<p style="color:black !important;">
								<?php if($user->member_one !=NULL): ?>
								<?php echo e($user->member_one); ?><br>
								<?php else: ?>
								<b style="color: red">Member 1 Not Found</b><br>
								<?php endif; ?>
								<?php if($user->member_two !=NULL): ?>
								<?php echo e($user->member_two); ?><br>
								<?php else: ?>
								<b style="color: red">Member 2 Not Found</b><br>
								<?php endif; ?>
								<?php if($user->member_three !=NULL): ?>
								<?php echo e($user->member_three); ?>

								<?php else: ?>
								<b style="color: red">Member 3 Not Found</b>
								<?php endif; ?>
							</p>
						</div>
						<div class="mb40">
							<h6 class="mb8 uppercase">School</h6>
							<p style="color:black !important;">
								<?php echo e($user->school); ?>

							</p>
						</div>
						<div class="mb40">
							<h6 class="mb8 uppercase">Province</h6>
							<p style="color:black !important;">
								<?php echo e($user->province); ?>

							</p>
						</div>
						<div class="mb40">
							<h6 class="mb8 uppercase">Contact</h6>
							<p style="color:black !important;">
								<?php echo e(App\User::find($user->team_id)->email); ?><br>
								<?php echo e($user->phone_num); ?><br>
								<?php echo e($user->line_id); ?>

							</p>
						</div>
					</div>
		            </div>
		        </div>
			</section>
			
			<section style="padding-top: 0px; padding-bottom: 0px">
		        <div class="container">
		            <div class="row">
						<?php if($user->member_one !=NULL): ?>
							<?php if($user->ktm_img1!=NULL): ?>
							<div class="col-md-4 col-sm-6">
			                    <div class="image-tile outer-title text-center" align="center">
									<h3 class="uppercase mb0"><?php echo e($user->member_one); ?></h3>  
			                        <img alt="Pic" src="<?php echo e(asset($user->ktm_img1)); ?>" style="display: block; max-width:400px; max-height:200px; width: auto; height: auto; margin: auto;">
			                        <div class="title mb16"><br>
										<a class="btn btn-lg btn-white mb8 mt-xs-24" href="<?php echo e(asset($user->ktm_img1)); ?>">Lihat KTM</a>
			                        </div>
			                        
			                    </div>
			                </div>
			                <?php else: ?>
							<h3 align="center">
				                KTM MEMBER 1 NOT UPLOADED<br>
							</h3>
							<?php endif; ?>
						<?php endif; ?>
						<?php if($user->member_two !=NULL): ?>
							<?php if($user->ktm_img2): ?>
							<div class="col-md-4 col-sm-6">
			                    <div class="image-tile outer-title text-center" align="center">
									<h3 class="uppercase mb0"><?php echo e($user->member_two); ?></h3>
			                        <img alt="Pic" src="<?php echo e(asset($user->ktm_img2)); ?>" style="display: block; max-width:400px; max-height:200px; width: auto; height: auto; margin: auto">
			                        <div class="title mb16"><br>
										<a class="btn btn-lg btn-white mb8 mt-xs-24" href="<?php echo e(asset($user->ktm_img2)); ?>">Lihat KTM</a>
			                        </div>
			                    </div>
			                </div>
			                <?php else: ?>
							<h3 align="center">
				                KTM MEMBER 2 NOT UPLOADED<br>
							</h3>
							<?php endif; ?>
						<?php endif; ?>
						<?php if($user->member_three !=NULL): ?>
							<?php if($user->ktm_img3 != NULL): ?>
							<div class="col-md-4 col-sm-6">
			                    <div class="image-tile outer-title text-center" align="center">
									<h3 class="uppercase mb0"><?php echo e($user->member_three); ?></h3>	
			                        <img alt="Pic" src="<?php echo e(asset($user->ktm_img3)); ?>" style="display: block; max-width:400px; max-height:200px; width: auto; height: auto; margin: auto">
			                        <div class="title mb16"><br>
										<a class="btn btn-lg btn-white mb8 mt-xs-24" href="<?php echo e(asset($user->ktm_img3)); ?>">Lihat KTM</a>	                            
			                        </div>
			                    </div>
			                </div>
			                <?php else: ?>
							<h3 align="center">
				                KTM MEMBER 3 NOT UPLOADED<br>
							</h3>
			                <?php endif; ?>
						<?php endif; ?>
		            </div>
		        </div>
			</section>
			<section style="padding-top: 0px; padding-bottom: 0px">
				<div class="container">
					<div class="feed-item mb96 mb-xs-48 text-center" align="center">
						<h4 align="center">Surat Keterangan Siswa Aktif</h4>	                
							<?php if($user->letter !=NULL): ?>
								<h4 align="center" style="color: green; font-weight: bold">
									SURAT KETERANGAN TELAH DIUPLOAD
								</h4>
								<a class="btn btn-lg btn-white mb8 mt-xs-24" href="<?php echo e(asset($user->letter)); ?>">Download Surat Keterangan</a>
							<?php else: ?>
								<h4 align="center" style="color: red; font-weight: bold">
									SURAT KETERANGAN BELUM DIUPLOAD
								</h4>
							<?php endif; ?>		                
					</div>
				</div>
			</section>
			<section style="padding-top: 0px; padding-bottom: 0px">	
				<div class="container">
					<div class="feed-item mb96 mb-xs-48 text-center">              
						<div class="row mb32 mb-xs-16">
							<div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1" align="center">
							<?php if($user->type != 'HackToday'): ?>
							<h4 align="center">Bukti Pembayaran</h4>  
								<?php if($user->payment!=NULL): ?>
								<img alt="Article Image" class="mb32 mb-xs-16" src="<?php echo e(asset($user->payment)); ?>" style="display: block; max-width:400px; max-height:200px; width: auto; height: auto; margin: auto">
								<br><a class="btn btn-lg btn-white mb8 mt-xs-24" href="<?php echo e(asset($user->payment)); ?>">Lihat Bukti Pembayaran</a>
								<?php else: ?>
								<b style="color: red">NOT UPLOADED</b>
								<?php endif; ?>  
							<?php endif; ?>      
							</div>
						</div>
						<br>
						<div class="row" align="center">
						<a class="btn btn-lg btn-white mb8 mt-xs-24 col-md-10 col-md-offset-1" href='<?php echo e(url("antiribetclub/verify/{$user->id}")); ?>'>Konfirmasi Pendaftaran</a>
						</div>
					</div>
				</div>
			</section>
		                    
					</div>
				</div>
			</div>
		</div>
	</div>
		
				
		<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/parallax.js')); ?>"></script>
        <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
    </body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>