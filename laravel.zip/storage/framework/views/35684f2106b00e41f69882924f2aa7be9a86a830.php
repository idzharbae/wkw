<?php $__env->startSection('content'); ?>
    <div class="main-container">
		<section class="page-title page-title-1 image-bg overlay parallax">
		        <div class="background-image-holder">
		            <img alt="Background Image" class="background-image" src="img/footer.png">
		        </div>
		        <div class="container">
		            <div class="row">
		                <div class="col-sm-12 text-center">
		                	<?php if($data->type == "AppsToday"): ?>
		                		<img alt="Screenshot" align="left" class="mb-xs-24" src="img/iconapps.png" style="width: auto; height: 200px;">
		                	<?php elseif($data->type == "HackToday"): ?>
								<img alt="Screenshot" align="left" class="mb-xs-24" src="img/iconhack.png" style="width: auto; height: 200px;">
		                	<?php elseif($data->type == "Business IT Case"): ?>
			                	<img alt="Screenshot" align="left" class="mb-xs-24" src="img/iconbisnis.png" style="width: auto; height: 200px;">
		                	<?php endif; ?>
		                </div>
		            </div>
		            
		        </div>

				<?php if($data->type != 'HackToday'): ?>		        
				<ol class="breadcrumb breadcrumb-2">
					<h3> <?php echo e($data->type); ?> </h3>
					<li>
						<a href="#profil">Profile</a>
					</li>
					<li>
						<a href="#berkas">Upload Berkas</a>
					</li>
					<li>
						<a href="#buktibayar">Upload Bukti Pembayaran</a>
					</li>
				</ol>
				<?php else: ?>
				<ol class="breadcrumb breadcrumb-2">
					<h3> <?php echo e($data->type); ?> </h3>
					<li>
						<a href="#profil">Profile</a>
					</li>
					<li>
						<a href="#berkas">Upload Berkas</a>
					</li>
				</ol>
				<?php endif; ?>
			</section>


			<section style="background-color:#26c99e;" id="profil">
		        <div class="container">
		            <div class="row">
					
                    <div class="feature bordered text-center bg-secondary" style="box-shadow: 0 9px 30px 10px rgba(0, 0, 0, 0.2); font-size: 18px">
						<div>
							<a class="bbtn tn-warning pull-right" href="<?php echo e(url('/editprofile')); ?>"  style="border-radius: 0;"><i class="fa fa-pencil-square-o"></i>EDIT PROFILE</a><br>
						</div>
						<h2 class="uppercase mb40 mb-xs-24"><?php echo e(App\User::find($data->team_id)->name); ?></h2>
						<div class="mb40">
							<h6 class="mb8 uppercase">Members</h6>
							<p style="color:black; !important;">
								<?php if($data->member_one!=NULL): ?>
								<?php echo e($data->member_one); ?><br />
								<?php endif; ?>
								<?php if($data->member_two!=NULL): ?>
								<?php echo e($data->member_two); ?><br />
								<?php endif; ?>
								<?php if($data->member_three!=NULL): ?>
								<?php echo e($data->member_three); ?>

								<?php endif; ?>
							</p>
						</div>
						<div class="mb40">
							<h6 class="mb8 uppercase">School</h6>
							<p style="color:black !important;">
								<?php echo e($data->school); ?>

							</p>
						</div>
						<div class="mb40">
							<h6 class="mb8 uppercase">Province</h6>
							<p style="color:black !important;">
								<?php echo e($data->province); ?>

							</p>
						</div>
						<div class="mb40">
							<h6 class="mb8 uppercase">Contact</h6>
							<p style="color:black !important;">
								<?php echo e(App\User::find($data->team_id)->email); ?><br>
								<?php echo e($data->phone_num); ?><br>
								<?php echo e($data->line_id); ?>

							</p>
						</div>
					</div>
		            </div>
		        </div>
			</section>
			
			<section style="background-color: #6290e0;" id="berkas">
		        <form method="POST" action='<?php echo e(url("/berkas")); ?>' enctype="multipart/form-data" >
		        	<?php echo e(csrf_field()); ?>


		    	<input type="hidden" name="id" value="<?php echo e($data->team_id); ?>">
		        <div class="container">

                    <h3 class="uppercase mb40 mb-xs-24 text-center" style="color:white;">Upload berkas</h3>
		            <div class="row">
		                <div class="col-md-4 col-sm-6">
		                    <div class="image-tile outer-title text-center">
								<?php if($data->member_one!=NULL): ?>
									<?php if($data->ktm_img1 != NULL): ?>
										<img alt="Pic" id="preview1" src="<?php echo e(asset($data->ktm_img1)); ?>" style="width: 577px; height: 224px; object-fit:cover;">
										<div class="title mb16">
		                            		<h5 class="uppercase mb0">
												<b> <?php echo e($data->member_one); ?> </b>
											</h5>
										</div>
										<input type="file" name="ktm_img1" class="btn btn-lg btn-white mb8 mt-xs-24" id="selectedFile1" style="display: none;" onchange="showname1();" />
										<input type="button"  class="btn btn-lg btn-white mb8 mt-xs-24" value="Upload KTM/Kartu Pelajar"  onclick="document.getElementById('selectedFile1').click();" />
										<div id="filename-1"></div>										
									<?php else: ?>
										<img alt="Pic" id="preview1" src="img/team-1.jpg" style="width: 577px; height: 224px; object-fit:cover;">
										<div class="title mb16">
		                            		<h5 class="uppercase mb0">
												<b> <?php echo e($data->member_one); ?> </b>
											</h5>
										</div>
										<input type="file" name="ktm_img1" class="btn btn-lg btn-white mb8 mt-xs-24" id="selectedFile1" style="display: none;" onchange="showname1();"/>
										<input type="button"  class="btn btn-lg btn-white mb8 mt-xs-24" value="Upload KTM/Kartu Pelajar"  onclick="document.getElementById('selectedFile1').click();" />
										<div id="filename-1"></div>
									<?php endif; ?>
								<?php else: ?>
									<img alt="Pic" id="preview1" src="img/restricted.ico" style="width: 577px; height: 224px; object-fit:cover;">
									<h5 class="uppercase mb0">
										<b style="color: red"> Member 1 Not Found </b>
									</h5>
								<?php endif; ?>
                            </div>
		                </div>
		                <div class="col-md-4 col-sm-6">
		                    <div class="image-tile outer-title text-center">
								<?php if($data->member_two!=NULL): ?>
									<?php if($data->ktm_img2 != NULL): ?>
										<img alt="Pic" id="preview2" src="<?php echo e(asset($data->ktm_img2)); ?>" style="width: 577px; height: 224px; object-fit:cover;">
										<div class="title mb16">
		                            		<h5 class="uppercase mb0">
												<b> <?php echo e($data->member_two); ?> </b>
											</h5>
										</div>
										<input type="file" name="ktm_img2" class="btn btn-lg btn-white mb8 mt-xs-24" id="selectedFile2" style="display: none;" onchange="showname2();"/>
										<input type="button"  class="btn btn-lg btn-white mb8 mt-xs-24" value="Upload KTM/Kartu Pelajar" onclick="document.getElementById('selectedFile2').click();" />
										<div id="filename-2"></div>
									<?php else: ?>
										<img alt="Pic" id="preview2" src="img/team-2.jpg" style="width: 577px; height: 224px; object-fit:cover;">
										<div class="title mb16">
		                            		<h5 class="uppercase mb0">
												<b> <?php echo e($data->member_two); ?> </b>
											</h5>
										</div>
										<input type="file" name="ktm_img2" class="btn btn-lg btn-white mb8 mt-xs-24" id="selectedFile2" style="display: none;" onchange="showname2();"/>
										<input type="button"  class="btn btn-lg btn-white mb8 mt-xs-24" value="Upload KTM/Kartu Pelajar" onclick="document.getElementById('selectedFile2').click();" />
										<div id="filename-2"></div>
									<?php endif; ?>
								<?php else: ?>
									<img alt="Pic" id="preview2" src="img/restricted.ico" style="width: 577px; height: 224px; object-fit:cover;">
									<h5 class="uppercase mb0">
										<b style="color: red"> Member 2 Not Found </b>
									</h5>
								<?php endif; ?>
                            </div>
		                </div>
		                <div class="col-md-4 col-sm-6">
		                    <div class="image-tile outer-title text-center">
								<?php if($data->member_three!=NULL): ?>
									<?php if($data->ktm_img3 != NULL): ?>
										<img alt="Pic" id="preview3" src="<?php echo e(asset($data->ktm_img3)); ?>" style="width: 577px; height: 224px; object-fit:cover;">
										<div class="title mb16">
		                            		<h5 class="uppercase mb0">
												<b> <?php echo e($data->member_three); ?> </b>
											</h5>
										</div>
										<input type="file" name="ktm_img3" class="btn btn-lg btn-white mb8 mt-xs-24" id="selectedFile3" style="display: none;" onchange="showname3();"/>
										<input type="button"  class="btn btn-lg btn-white mb8 mt-xs-24" value="Upload KTM/Kartu Pelajar" onclick="document.getElementById('selectedFile3').click();" />
										<div id="filename-3"></div>
									<?php else: ?>
										<img alt="Pic" id="preview3" src="img/team-3.jpg" style="width: 577px; height: 224px; object-fit:cover;">
										<div class="title mb16">
		                            		<h5 class="uppercase mb0">
												<b> <?php echo e($data->member_three); ?> </b>
											</h5>
										</div>
										<input type="file" name="ktm_img3" class="btn btn-lg btn-white mb8 mt-xs-24" id="selectedFile3" style="display: none;" onchange="showname3();"/>
										<input type="button"  class="btn btn-lg btn-white mb8 mt-xs-24" value="Upload KTM/Kartu Pelajar" onclick="document.getElementById('selectedFile3').click();" />
										<div id="filename-3"></div>
									<?php endif; ?>
								<?php else: ?>
									<img alt="Pic" id="preview3" src="img/restricted.ico" style="width: 577px; height: 224px; object-fit:cover;">
									<h5 class="uppercase mb0">
										<b style="color: red"> Member 3 Not Found </b>
									</h5>
								<?php endif; ?>
                            </div>
		                </div>
					</div>
					<p align="center">Foto/hasil scan KTM/Kartu Pelajar diupload dalam format .jpg,.jpeg, atau .png dengan ukuran file < 2 MB</p>
					
		            <div class="row">
		                <div class="col-sm-12 text-center">
		                	<input type="file" name="letter" class="btn btn-lg btn-white mb8 mt-xs-24" id="selectedFile4" style="display: none;" onchange="showname4();"/>
							<input type="button" style="white-space: normal; height: auto;"  class="btn btn-lg btn-white mb8 mt-xs-24" value="Upload Surat Keterangan Mahasiswa/Siswa Aktif" onclick="document.getElementById('selectedFile4').click();" />
							<!-- <a class="btn btn-lg btn-white mb8 mt-xs-24" href="#">Upload Surat Keterangan Mahasiswa/Siswa Aktif</a> -->
							<div id="filename-4"></div>
							<br><p>Surat keterangan semua anggota tim disatukan menjadi satu file dalam format .pdf dengan ukuran file tidak lebih dari 2 MB</p>
                            
                            <?php if($data->letter == NULL): ?>
                            <h5 class="uppercase mb0" style="color: #a3031b; font-weight: bold">Surat Keterangan Mahasiswa Aktif Belum Diupload</h5>                       
                            <?php else: ?>
                            <h5 class="uppercase mb0" style="color: #1a8e02; font-weight: bold">Surat Keterangan Mahasiswa Aktif Berhasil Diupload</h5>                       
                            <?php endif; ?>
							<br>
							<input class="btn btn-lg btn-white mb8 mt-xs-24" type="submit" value="SIMPAN PERUBAHAN" >
                        </div>
		            </div>
		        </div>
		        </form>
		        </section>
				<?php if($data->type != 'HackToday'): ?>
					<?php if($data->payment == NULL): ?>
					<section style="background-color: #ff3333" id="buktibayar">
					<?php else: ?>
						<?php if($data->verify == 1): ?>
						<section style="background-color: #26c99e" id="buktibayar">
						<?php else: ?>
						<section style="background-color: #fff83f" id="buktibayar">
						<?php endif; ?>
					<?php endif; ?>
				<?php endif; ?>
		        <div class="container">
		            <div class="row">
		                <div class="col-sm-12 text-center">
							<?php if($data->type != 'HackToday'): ?>
								<?php if($data->payment == NULL): ?>
								<h3 class="uppercase mb40 mb-xs-24" style="color:white;">BUKTI PEMBAYARAN BELUM DIUPLOAD</h3>
								<a class="btn btn-lg btn-white mb8 mt-xs-24" href="<?php echo e(route('payment')); ?>">Upload Bukti Pembayaran</a>
								<?php else: ?>
									<?php if($data->verify == 1): ?>
									<h3 class="uppercase mb40 mb-xs-24" style="color:white;">PEMBAYARAN BERHASIL DIVERIFIKASI</h3>
									<?php else: ?>
									<h3 class="uppercase mb40 mb-xs-24" style="color:black;">MENUNGGU VERIFIKASI PEMBAYARAN</h3>
									<a class="btn btn-lg btn-white mb8 mt-xs-24" href="<?php echo e(route('payment')); ?>">Update Bukti Pembayaran</a>
									<?php endif; ?>
								<?php endif; ?>
							<?php endif; ?>
		                </div>
		            </div>
		            
		        </div>

			</div>
		    </section></div>
		
				
		<script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/parallax.js"></script>
		<script src="js/scripts.js"></script>						
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>