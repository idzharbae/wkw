				
		<div class="nav-container">
		    
		    
		
		    <nav>
		
		        <div class="nav-bar text-center">
		            <div class="col-md-2 col-md-push-5 col-sm-12 text-center">
		                <a href="#">
		                    <img alt="logo" class="image-xxs" src="img/logo-dark.png">
		                </a>
		            </div>
		
		            <div class="col-sm-12 col-md-5 col-md-pull-2 overflow-hidden-xs">
		                <ul class="menu inline-block pull-right">
		                    <li><a href="#">Home</a></li>
		                    <!-- <li><a href="#">Dropdown</a> -->
		                        <ul>
		                            <li><a href="#">Single</a></li>
		                        </ul>
		                    </li>
		                </ul>
		            </div>
		        
		            <div class="col-sm-12 col-md-5 pb-xs-24">
		                <ul class="menu">
		                    <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
							<li><a href="<?php echo e(route('register')); ?>">Register</a></li>
		                    <!-- <li><a href="#">Dropdown</a> -->
		                        <!-- <ul>
		                            <li><a href="#">Register</a></li>
									<li><a href="#">Login</a></li>
		                        </ul> -->
		                    </li>
		                </ul>
		            </div>
		        </div>
		
		        <div class="module widget-handle mobile-toggle right visible-sm visible-xs absolute-xs">
		            <i class="ti-menu"></i>
		        </div>
		    </nav>
		</div>