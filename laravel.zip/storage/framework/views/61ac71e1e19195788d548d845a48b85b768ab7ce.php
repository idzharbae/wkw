<?php echo e($slot); ?>

